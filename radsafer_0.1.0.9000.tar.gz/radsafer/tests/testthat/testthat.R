library(testthat)
library(radsafer)

# test_check("radsafer")
