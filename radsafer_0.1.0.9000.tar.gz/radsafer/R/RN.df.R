#' @title Radionuclide emmision data excluding beta from ICRP 107
#' 
#' @description Nuclear decay data for beta emission. This was obtained from the
#'   Radiological Toolbox, from Oak Ridge National Laboratory and the United
#'   States Nuclear Regulatory Commission. The data originated in ICRP
#'   Publication 107, and were prepared for that publication by A. Endo of the
#'   Japan Atomic Energy Agency and K. Eckerman of Oak Ridge National Laboratory
#'   (ORNL).
#' @format A tibble with six columns, which are: 
#' \describe{
#' \item{RN}{the radionuclide: atomic number - atomic mass}
#' \item{code_AN}{radiation abbreviaion}
#' \item{E_MeV}{discrete energy in MeV of emission}
#' \item{prob}{probability per decay of this emission}
#' \item{code_num}{radiation type code}
#' \item{short_code}{provided to allow easy pull of all photons}
#' 
#' }
"RN.df"
