#' radsafer package
#' 
#' Functions for Radiation Safety
#' 
#' @docType package
#' 
#' @author Mark Hogue \email{mark.hogue.chp@gmail.com}
#' 
#' @name radsafer
NULL